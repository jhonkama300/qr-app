import ChangePasswordForm from "@/components/change-password-form"

export default function ChangePasswordPage() {
  return <ChangePasswordForm />
}
