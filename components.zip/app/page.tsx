import { UnifiedLogin } from "@/components/unified-login"

export default function Home() {
  return <UnifiedLogin />
}
