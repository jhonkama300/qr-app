import StudentDashboard from "@/components/student-dashboard"

export default function StudentDashboardPage() {
  return <StudentDashboard />
}
