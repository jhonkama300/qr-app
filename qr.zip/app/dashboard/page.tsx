import { SPADashboard } from "@/components/spa-dashboard"

export default function Dashboard() {
  return <SPADashboard initialView="escanear" />
}
