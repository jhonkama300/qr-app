import StudentLoginForm from "@/components/student-login-form"

export default function StudentLoginPage() {
  return <StudentLoginForm />
}
